-- Insert sample user data
INSERT INTO "user" (
    id,
    first_name,
    last_name,
    email,
    phone,
    lead_source
)
VALUES (
    '66666666-6666-6666-6666-666666666666',
    'Alex',
    'Rivera',
    'arivera@example.com',
    '555-111-2222',
    'Website'
);
